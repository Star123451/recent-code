package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name="My OpMode", group="My Group")
public class MyOpMode extends LinearOpMode {
    // Define Motor and Servo objects (Make them private so they can't be accessed externally)
    private DcMotor  FL  = null;
    private DcMotor BL  = null;
    private DcMotor FR   = null;
    private DcMotor BR  = null;
    private DcMotor  ARM  = null;
    private DcMotor HAND = null; // New HAND motor

    // Define Servo objects
    private Servo handServo1 = null;
    private Servo handServo2 = null;
    private Servo handServo3 = null;

    // Constants for servo positions (adjust these as needed)
    public static final double HAND_OPEN_POSITION = 0.0; // Example: Fully open
    public static final double HAND_CLOSED_POSITION = 1.0; // Example: Fully closed
    public static final double HAND_MID_POSITION = 0.5; // Example: Halfway open/closed

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize the motors and servos
        FL = hardwareMap.get(DcMotor.class, "FL");
        BL = hardwareMap.get(DcMotor.class, "BL");
        FR = hardwareMap.get(DcMotor.class, "FR");
        BR = hardwareMap.get(DcMotor.class, "BR");
        ARM = hardwareMap.get(DcMotor.class, "ARM");
        HAND = hardwareMap.get(DcMotor.class, "HAND"); // Initialize HAND motor

        // Initialize Servos
        handServo1 = hardwareMap.get(Servo.class, "handServo1");
        handServo2 = hardwareMap.get(Servo.class, "handServo2");
        handServo3 = hardwareMap.get(Servo.class, "handServo3");

        // Set Motor Directions
        FL.setDirection(DcMotor.Direction.FORWARD);
        BL.setDirection(DcMotor.Direction.FORWARD);
        FR.setDirection(DcMotor.Direction.REVERSE);
        BR.setDirection(DcMotor.Direction.REVERSE);
        HAND.setDirection(DcMotor.Direction.FORWARD); // Or REVERSE, depending on your robot

        // Set Motor Modes
        FL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        BL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        FR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        BR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        HAND.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ARM.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);


        // Set Servo Positions (initial positions)
        handServo1.setPosition(HAND_MID_POSITION);
        handServo2.setPosition(HAND_MID_POSITION);
        handServo3.setPosition(HAND_MID_POSITION);

        // Wait for the start button to be pressed
        waitForStart();

        // Main loop for controlling the robot
        while (opModeIsActive()) {
            // Mecanum drive logic (as explained in previous responses)
            double leftStickY = -gamepad1.left_stick_y;
            double rightStickX = gamepad1.right_stick_x;
            double leftStickX = gamepad1.left_stick_x;

            // Calculate the power for each motor
            double frontLeftPower = leftStickY + rightStickX;
            double frontRightPower = leftStickY - rightStickX;
            double backLeftPower = leftStickY + leftStickX;
            double backRightPower = leftStickY - leftStickX;

            // Set the power for each motor
            FL.setPower(frontLeftPower);
            FR.setPower(frontRightPower);
            BL.setPower(backLeftPower);
            BR.setPower(backRightPower);

            // Control the HAND motor (example: using right trigger)
            double handPower = gamepad1.right_trigger;
            HAND.setPower(handPower);

            // Control the ARM motor (example: using dpad up and down)
            if (gamepad1.dpad_up) ARM.setPower(1.0); // Move arm up
            else if (gamepad1.dpad_down) ARM.setPower(-1.0); // Move arm down
            else ARM.setPower(0.0); // Stop arm movement
            // Control the Servos (example: using left bumper)
            if (gamepad1.left_bumper) {
                // Open the hand
                handServo1.setPosition(HAND_OPEN_POSITION);
                handServo2.setPosition(HAND_OPEN_POSITION);
                handServo3.setPosition(HAND_OPEN_POSITION);
            } else if (gamepad1.right_bumper) {
                // Close the hand
                handServo1.setPosition(HAND_CLOSED_POSITION);
                handServo2.setPosition(HAND_CLOSED_POSITION);
                handServo3.setPosition(HAND_CLOSED_POSITION);
            }

            // Telemetry
            telemetry.addData("FL Power", FL.getPower());
            telemetry.addData("FR Power", FR.getPower());
            telemetry.addData("BL Power", BL.getPower());
            telemetry.addData("BR Power", BR.getPower());
            telemetry.addData("ARM Power", ARM.getPower());
            telemetry.addData("HAND Power", HAND.getPower());
            telemetry.addData("Hand Servo 1", handServo1.getPosition());
            telemetry.addData("Hand Servo 2", handServo2.getPosition());
            telemetry.addData("Hand Servo 3", handServo3.getPosition());
            telemetry.update();
        }
    }
}