package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;


public class RobotHardware
{
    /* Public OpMode members. */
    public DcMotor  FL   = null;
    public DcMotor  BL  = null;
    public DcMotor  FR   = null;
    public DcMotor  BR  = null;
    public DcMotor  ARM   = null;
    public DcMotor  HAND   = null;
    public Servo    handServo1    = null;
    public Servo    handServo2    = null;
    public Servo    handServo3    = null;

    /* local OpMode members. */
    HardwareMap hwMap           =  null;
    private ElapsedTime period  = new ElapsedTime();

    /* Constructor */
    public RobotHardware(){

    }

    /* Initialize standard Hardware interfaces */
    public void init(HardwareMap ahwMap) {
        // Save reference to Hardware map
        hwMap = ahwMap;

        // Define and Initialize Motors
        FL   = hwMap.dcMotor.get("FL");
        BL  = hwMap.dcMotor.get("BL");
        FR   = hwMap.dcMotor.get("FR");
        BR  = hwMap.dcMotor.get("BR");
        ARM   = hwMap.dcMotor.get("ARM");
        HAND   = hwMap.dcMotor.get("HAND");
        handServo1 = hwMap.servo.get("handServo1");
        handServo2 = hwMap.servo.get("handServo2");
        handServo3 = hwMap.servo.get("handServo3");

        FL.setDirection(DcMotor.Direction.REVERSE);
        BL.setDirection(DcMotor.Direction.REVERSE);
        FR.setDirection(DcMotor.Direction.FORWARD);
        BR.setDirection(DcMotor.Direction.FORWARD);
        ARM.setDirection(DcMotor.Direction.FORWARD);
        HAND.setDirection(DcMotor.Direction.FORWARD);

        // Set all motors to zero power
        FL.setPower(0);
        BL.setPower(0);
        FR.setPower(0);
        BR.setPower(0);
        ARM.setPower(0);
        HAND.setPower(0);


        // Set all motors to run without encoders.
        // May want to use RUN_USING_ENCODERS if encoders are installed.
        FL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        BL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        FR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        BR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ARM.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        HAND.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Set servos to their initial positions.
        handServo1.setPosition(0.0);
        handServo2.setPosition(0.0);
        handServo3.setPosition(0.0);
    }
}