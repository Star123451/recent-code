// MOTOR 0: BOTTOM RIGHT
// MOTOR 1: TOP RIGHT
// MOTOR 2: BOTTOM LEFT
// MOTOR 3: TOP LEFT
// MOTOR 0 AND 1 IS RIGHT, MOTOR 2 AND 3 IS LEFT

package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;


@TeleOp

public class Movement extends LinearOpMode {
    private DcMotor bottomLeft;
    private DcMotor topRight;
    private DcMotor bottomRight;
    private DcMotor topLeft;


    @Override
    public void runOpMode() {
        bottomLeft = hardwareMap.get(DcMotor.class, "bottom left");
        topRight = hardwareMap.get(DcMotor.class, "top right");
        bottomRight = hardwareMap.get(DcMotor.class, "bottom right");
        topLeft = hardwareMap.get(DcMotor.class, "top left");

        telemetry.addData("Status", "Initialized");
        telemetry.update();
        // Wait for the game to start (driver presses PLAY)
        waitForStart();

        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            //DRIVETRAIN CODE
            double leftAxis = -gamepad1.left_stick_y;
            double rightAxis = -gamepad1.right_stick_y;

            double leftPower = -leftAxis;

            bottomLeft.setPower(leftPower);
            topLeft.setPower(leftPower);
            bottomRight.setPower(rightAxis);
            topRight.setPower(rightAxis);

            telemetry.update();
        }
    }
}

