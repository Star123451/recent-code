package org.firstinspires.ftc.robotcontroller.external.samples;

public class OpModeMove {
}
